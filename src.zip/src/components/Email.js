import React, { Component } from 'react'

class Template extends Component{
    constructor(props){
        super(props)
        this.state = {
            name : 'email',
            content : 'emailContent',
            message : ''
        }
        this.handleChange = this.handleChange.bind();
    }

    handleSubmit = ()=>{
        console.log(this.state)
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.state)
        };
        fetch('http://localhost:8080/saveTemplate', requestOptions)
            .then(response => response.json())
            .then(data => this.setState({ message: data }));
    }

    handleChange = e =>{
        console.log(e.target.value)
        this.setState({
            [e.target.name] : e.target.value
        })
        e.preventDefault();
    }



    render() {
        const {name, content} = this.state;
        return (
            <div>
                <form onSubmit={this.handleSubmit}>
                    <label>
                        Profile:
                        <input id="nameId" type="text" name={name} value={name} onChange={this.handleChange}/>
                    </label>
                    <label>
                        Content:
                        <textarea id="contentId" name={content}  value={content} onChange={this.handleChange}/>
                    </label>
                    <input type="submit" value="Submit" />
                </form>
                {this.state.message}
            </div>
        )
    }
}

export default Template