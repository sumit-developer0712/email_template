import React from 'react';
import logo from './logo.svg';
import './App.css';
import Template from './components/Email';

function App() {
  return (
    <div className="App">
      <Template/>
    </div>
  );
}

export default App;
